const express = require('express');
let data = []

const index = (req, res) => {
    res.render('index');
}

const aboutDoc = (req, res) => {
    res.render('about');
}

const editDoc = (req, res) => {
    res.render('edit');
}

module.exports = {index, aboutDoc, editDoc}